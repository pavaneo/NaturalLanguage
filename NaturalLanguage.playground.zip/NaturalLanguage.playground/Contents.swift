/// Import Natural Language FrameWork.
import NaturalLanguage

/// String to be convert Token.
let convertToToken = "I Love Fast Cars And To Go Too Fast In Them"

/// Get Instance of NLTagger.
let tagger = NLTagger(tagSchemes: [.tokenType])

/// Tagger to look for names.
tagger.string = convertToToken

/// We call our enumerateTags method to convert string to token.
tagger.enumerateTags(in: convertToToken.startIndex..<convertToToken.endIndex, unit: .word, scheme: .tokenType, options: [.omitPunctuation, .omitWhitespace]) { (tag, range) -> Bool in
    print(convertToToken[range])
    return true
}
